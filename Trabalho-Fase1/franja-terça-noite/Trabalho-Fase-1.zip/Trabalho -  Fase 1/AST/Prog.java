
package AST;

//prog ::= P pid ’;’ body ’.’
public class Prog{

	private Char pid_;
	private Body body_;
	
	public Program(Char p, Body b){
		
		this.pid_ = p;
		this.body_ = b;
	}
	
	


}