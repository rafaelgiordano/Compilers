
package AST;

//prog ::= P pid ’;’ body ’.’
public class Stmt{

	private List<String> vblist;

	// stmt ::= L ’(’ vblist ’)’
	public Stmt(List<String> v){
		
		this.vblist = v;

	}
	
	


}