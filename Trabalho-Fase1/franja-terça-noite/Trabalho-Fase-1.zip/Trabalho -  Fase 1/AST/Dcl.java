
package AST;

//dcl ::= idlist ’:’ type ’;’

public class Dcl{

	private List<String> id;
	
	public Dcl(List<String> arrId){
		this.id = d;
	}


}