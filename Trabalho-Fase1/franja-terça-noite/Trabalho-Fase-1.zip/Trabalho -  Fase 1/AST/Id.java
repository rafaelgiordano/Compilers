package AST;

//id ::= letter {letter | digit}
public class Id(){

	private Character c_;
	private Integer i_;

	public Id(Character c, Integer i){
		this.c_ = c;
		this.i_ = i;
	}




}