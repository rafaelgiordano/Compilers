
package AST;

//prog ::= P pid ’;’ body ’.’
public class Stmt{

	
	
	public Stmt(){
		
		

	}
	
	


}