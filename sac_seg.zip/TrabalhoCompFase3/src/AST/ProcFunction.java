package AST;


public abstract class ProcFunction extends Stmt {
	public abstract void genC(PW pw);
}
