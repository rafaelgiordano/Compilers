#include <stdio.h>

int main() {
int
a,bif(
>){a = 3*9};
return 0;   
}
